-- Adminer 4.6.3 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://picsum.photos/300/200',
  `date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `articles_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `articles_ibfk_4` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `articles` (`id`, `title`, `content`, `img`, `date`, `user_id`, `category_id`) VALUES
(1,	'Life goal',	'Have you ever stopped to think about your life goals?\r\n\r\nLife goals are the things you’d like to achieve in order to be satisfied with your future and who you become. Your personal goals could range from better relationships, to starting a business, to traveling the world.\r\n\r\nSome goals are specific; others are flexible and open to interpretation.\r\n\r\nHowever, without at least one goal to progress towards, you won’t experience much personal development.\r\n\r\nLuckily for you, this article is all about how to set life goals that will set you up for a life of success.',	'https://scontent-frt3-1.cdninstagram.com/vp/6e0fad24e795a334be8bf8e826bad917/5D7E6790/t51.2885-15/e35/61247609_890650544618158_1946508318470888061_n.jpg?_nc_ht=scontent-frt3-1.cdninstagram.com&ig_cache_key=MjA1ODI1ODU2NTk4NzMyMjAxMg%3D%3D.2',	'2019-07-02',	1,	1),
(3,	'Health food',	'Health food is a marketing term to suggest human health effects beyond a normal healthy diet required for human nutrition. Foods marketed as health foods may be part of one or more categories, such as natural foods, organic foods, whole foods, vegetarian foods or dietary supplements.[citation needed] These products may be sold in health food stores or in the health food or organic sections of grocery stores. While there is no precise definition for \"health food\", the United States Food and Drug Administration monitors and warns food manufacturers against labeling foods as having specific health effects when no evidence exists to support such statements.',	'https://picsum.photos/300/200',	'2019-07-03',	1,	1);

DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`id`, `name`) VALUES
(1,	'Lifestyle'),
(2,	'Gamers'),
(3,	'Shopping');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL DEFAULT '0',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `role`, `password`) VALUES
(1,	'Admin',	1,	'21232f297a57a5a743894a0e4a801fc3'),
(7,	'Toto',	0,	'f71dbe52628a3f83a77ab494817525c6'),
(9,	'Lolo',	0,	'4a7d1ed414474e4033ac29ccb8653d9b'),
(10,	'PierrePaulJacques',	1,	'patate');

-- 2019-07-05 14:26:43
